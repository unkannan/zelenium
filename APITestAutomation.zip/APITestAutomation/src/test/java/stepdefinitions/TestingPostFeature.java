package stepdefinitions;

import static org.testng.Assert.assertEquals;

import org.json.JSONObject;

import cucumber.api.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class TestingPostFeature {
	
	static Response response=null;
	static String basePath=null;
	
@Given("^I want to execute createSingletUsersList endpoint$")
public void i_want_to_execute_createSingletUsersList_endpoint() throws Throwable {
	System.out.println("End Point id for Post request is declared");
	basePath="/v1/create";
	RestAssured.basePath=basePath;
}

@When("^I submit the POST request for create single user$")
public void i_submit_the_POST_request_for_create_single_user() throws Throwable {
	
	//Sending Test Data to get created 
	 JSONObject json=new JSONObject();
	 json.put("name","Rajshekar");
	 json.put("job","Software Engineer");
	 
	response=RestAssured.given()
				.contentType("application/json")
				.body(json.toString())
				.post();
	System.out.println("Request is sent");
}

@Then("^I should get (\\d+) sucess status code along with resonse body$")
public void i_should_get_sucess_status_code_along_with_resonse_body(int arg1) throws Throwable {
	System.out.println(response.getStatusCode());
		System.out.println(response.getBody().asString());
		
		assertEquals(response.getStatusCode(), 201);
}



}
