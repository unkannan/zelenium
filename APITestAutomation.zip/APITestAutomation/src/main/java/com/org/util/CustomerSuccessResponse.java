package com.org.util;

public class CustomerSuccessResponse {

	public String SuccessCode;
	public String Message;
	
}
